// lib/features/categorias/ui/views/integrantes_page.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../Categorias/domain/entities/categoria_item.dart';
import '../../../Categorias/domain/entities/grupo_integrante.dart';
import '../viewmodels/categoria_controller.dart';

class IntegrantesPage extends StatelessWidget {
  final CategoriaItem categoria;

  IntegrantesPage({super.key, required this.categoria});

  final Color backgroundColor = const Color(0xFFF4F5EF);
  final Color accentColor = const Color(0xFF7E57C2);

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<CategoriaController>();
    controller.cargarIntegrantes(categoria.id);

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: backgroundColor,
        foregroundColor: Colors.black,
        centerTitle: true,
        title: const Text(
          'Grupo e integrantes',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Obx(() {
            if (controller.isLoadingIntegrantes.value) {
              return const Center(child: CircularProgressIndicator());
            }

            if (controller.integrantes.isEmpty) {
              return const Center(
                child: Text(
                  'No hay integrantes registrados en esta categoría.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black54),
                ),
              );
            }

            final Map<String, List<GrupoIntegrante>> gruposMap = {};
            for (final integrante in controller.integrantes) {
              gruposMap.putIfAbsent(integrante.nombreGrupo, () => []);
              gruposMap[integrante.nombreGrupo]!.add(integrante);
            }

            return ListView(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Text(
                    categoria.nombre,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                ...gruposMap.entries.map((entry) {
                  return _buildGrupoTable(entry.key, entry.value);
                }),
              ],
            );
          }),
        ),
      ),
    );
  }

  Widget _buildGrupoTable(
    String nombreGrupo,
    List<GrupoIntegrante> integrantes,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Grupo: $nombreGrupo',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.bold,
              color: accentColor,
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowColor: WidgetStateProperty.all(
                accentColor.withOpacity(0.12),
              ),
              columns: const [
                DataColumn(
                  label: Text(
                    '#',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'Integrantes',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
              rows: List.generate(
                integrantes.length,
                (index) => DataRow(
                  cells: [
                    DataCell(Text('${index + 1}')),
                    DataCell(Text(integrantes[index].correo)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
