import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../cursos/domain/entities/curso_curso.dart';
import '../../../Categorias/domain/entities/categoria_item.dart';
import '../viewmodels/categoria_controller.dart';
import 'integrantes_page.dart';

class CategoriasPage extends StatelessWidget {
  final CursoCurso curso;

  CategoriasPage({super.key, required this.curso});

  final Color backgroundColor = const Color(0xFFF4F5EF);
  final Color accentColor = const Color(0xFF7E57C2); // cambia respecto a cursos
  final Color accentSoft = const Color(0xFFEDE7F6);

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<CategoriaController>();
    controller.cargarCategorias(curso.id);

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: backgroundColor,
        foregroundColor: Colors.black,
        centerTitle: true,
        title: const Text(
          'Categorías',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeaderCard(),
              const SizedBox(height: 20),
              const Text(
                'Subcategorías',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: Obx(() {
                  if (controller.isLoadingCategorias.value) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (controller.categorias.isEmpty) {
                    return const Center(
                      child: Text(
                        'Este curso aún no tiene categorías cargadas.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black54),
                      ),
                    );
                  }

                  final colors = [
                    const Color(0xFF7E57C2),
                    const Color(0xFF5C6BC0),
                    const Color(0xFF8E24AA),
                    const Color(0xFF6A1B9A),
                  ];

                  return ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    itemCount: controller.categorias.length,
                    itemBuilder: (context, index) {
                      final categoria = controller.categorias[index];
                      return _buildCategoriaCard(
                        categoria,
                        colors[index % colors.length],
                      );
                    },
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: accentSoft,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            curso.nombre,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(
            'Código: ${curso.id}',
            style: const TextStyle(color: Colors.black54),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoriaCard(CategoriaItem categoria, Color colorBanner) {
    return GestureDetector(
      onTap: () {
        Get.to(() => IntegrantesPage(categoria: categoria));
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 65,
              decoration: BoxDecoration(
                color: colorBanner,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      categoria.nombre,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                      ),
                    ),
                  ),
                  Icon(Icons.chevron_right, color: accentColor),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
