import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import '../../domain/entities/categoria_item.dart';
import '../../domain/entities/grupo_integrante.dart';
import '../../domain/repositories/i_categoria_repository.dart';

class CategoriaController extends GetxController {
  final ICategoriaRepository repository;

  CategoriaController({required this.repository});

  final categorias = <CategoriaItem>[].obs;
  final integrantes = <GrupoIntegrante>[].obs;

  final isLoadingCategorias = false.obs;
  final isLoadingIntegrantes = false.obs;

  Future<void> cargarCategorias(String idCurso) async {
    try {
      isLoadingCategorias.value = true;
      final result = await repository.getCategoriasByCurso(idCurso);
      categorias.assignAll(result);
    } catch (e) {
      debugPrint('Error cargando categorías: $e');
      Get.snackbar('Error', 'No se pudieron cargar las categorías');
    } finally {
      isLoadingCategorias.value = false;
    }
  }

  Future<void> cargarIntegrantes(String idCategoria) async {
    try {
      isLoadingIntegrantes.value = true;
      final result = await repository.getIntegrantesByCategoria(idCategoria);
      integrantes.assignAll(result);
    } catch (e) {
      debugPrint('Error cargando integrantes: $e');
      Get.snackbar('Error', 'No se pudieron cargar los integrantes');
    } finally {
      isLoadingIntegrantes.value = false;
    }
  }
}
