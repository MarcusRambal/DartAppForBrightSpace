import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../../../../../core/i_local_preferences.dart';
import '../../domain/entities/categoria_item.dart';
import '../../domain/entities/grupo_integrante.dart';
import 'i_categoria_source.dart';

class CategoriaSourceServiceRoble implements ICategoriaSource {
  final http.Client httpClient;

  final contract = dotenv.get(
    'EXPO_PUBLIC_ROBLE_PROJECT_ID',
    fallback: "NO_ENV",
  );

  final String baseUrl = 'roble-api.openlab.uninorte.edu.co';

  CategoriaSourceServiceRoble({http.Client? client})
    : httpClient = client ?? http.Client();

  Future<String> _getValidToken() async {
    final ILocalPreferences sharedPreferences = Get.find();
    String? token = await sharedPreferences.getString('token');

    if (token == null) {
      final authRepo = Get.find();
      final refreshed = await authRepo.refreshToken();
      if (!refreshed) throw Exception("No se pudo refrescar el token");
      token = await sharedPreferences.getString('token');
      if (token == null) throw Exception("Token sigue siendo null");
    }

    return token;
  }

  @override
  Future<List<CategoriaItem>> getCategoriasByCurso(String idCurso) async {
    final token = await _getValidToken();

    final uri = Uri.https(baseUrl, '/database/$contract/read', {
      'tableName': 'Categoria',
      'idCurso': idCurso,
    });

    final response = await httpClient.get(
      uri,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('No se pudieron cargar las categorías');
    }

    final List decoded = jsonDecode(response.body);

    final categorias = decoded.map((e) => CategoriaItem.fromJson(e)).toList();

    categorias.sort(
      (a, b) => a.nombre.toLowerCase().compareTo(b.nombre.toLowerCase()),
    );
    return categorias;
  }

  @override
  Future<List<GrupoIntegrante>> getIntegrantesByCategoria(
    String idCategoria,
  ) async {
    final token = await _getValidToken();

    final uri = Uri.https(baseUrl, '/database/$contract/read', {
      'tableName': 'Grupos',
      'idCat': idCategoria,
    });

    final response = await httpClient.get(
      uri,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode != 200) {
      throw Exception('No se pudieron cargar los integrantes');
    }

    final List decoded = jsonDecode(response.body);

    final integrantes = decoded
        .map((e) => GrupoIntegrante.fromJson(e))
        .toList();

    integrantes.sort((a, b) {
      final grupoCompare = a.nombreGrupo.toLowerCase().compareTo(
        b.nombreGrupo.toLowerCase(),
      );
      if (grupoCompare != 0) return grupoCompare;
      return a.correo.toLowerCase().compareTo(b.correo.toLowerCase());
    });

    return integrantes;
  }
}
