import '../../domain/entities/categoria_item.dart';
import '../../domain/entities/grupo_integrante.dart';

abstract class ICategoriaSource {
  Future<List<CategoriaItem>> getCategoriasByCurso(String idCurso);
  Future<List<GrupoIntegrante>> getIntegrantesByCategoria(String idCategoria);
}
