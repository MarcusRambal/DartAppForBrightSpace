import '../../domain/entities/categoria_item.dart';
import '../../domain/entities/grupo_integrante.dart';
import '../../domain/repositories/i_categoria_repository.dart';
import '../dataSources/i_categoria_source.dart';

class CategoriaRepository implements ICategoriaRepository {
  final ICategoriaSource source;

  CategoriaRepository(this.source);

  @override
  Future<List<CategoriaItem>> getCategoriasByCurso(String idCurso) async {
    return await source.getCategoriasByCurso(idCurso);
  }

  @override
  Future<List<GrupoIntegrante>> getIntegrantesByCategoria(
    String idCategoria,
  ) async {
    return await source.getIntegrantesByCategoria(idCategoria);
  }
}
