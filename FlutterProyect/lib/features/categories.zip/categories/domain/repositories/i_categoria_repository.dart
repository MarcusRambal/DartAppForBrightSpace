import '../entities/categoria_item.dart';
import '../entities/grupo_integrante.dart';

abstract class ICategoriaRepository {
  Future<List<CategoriaItem>> getCategoriasByCurso(String idCurso);
  Future<List<GrupoIntegrante>> getIntegrantesByCategoria(String idCategoria);
}
