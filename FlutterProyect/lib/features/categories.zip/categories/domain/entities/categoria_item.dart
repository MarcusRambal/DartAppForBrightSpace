class CategoriaItem {
  final String id;
  final String nombre;
  final String idCurso;

  CategoriaItem({
    required this.id,
    required this.nombre,
    required this.idCurso,
  });

  factory CategoriaItem.fromJson(Map<String, dynamic> json) {
    return CategoriaItem(
      id: json['idcat'].toString(),
      nombre: (json['nom'] ?? json['nombre'] ?? 'Sin nombre').toString(),
      idCurso: json['idCurso'].toString(),
    );
  }
}
