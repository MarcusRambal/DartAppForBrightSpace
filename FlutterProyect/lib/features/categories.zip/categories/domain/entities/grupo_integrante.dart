class GrupoIntegrante {
  final String idGrupo;
  final String nombreGrupo;
  final String correo;

  GrupoIntegrante({
    required this.idGrupo,
    required this.nombreGrupo,
    required this.correo,
  });

  factory GrupoIntegrante.fromJson(Map<String, dynamic> json) {
    return GrupoIntegrante(
      idGrupo: json['idGrupo'].toString(),
      nombreGrupo: (json['nombre'] ?? 'Grupo').toString(),
      correo: (json['Correo'] ?? '').toString(),
    );
  }
}
